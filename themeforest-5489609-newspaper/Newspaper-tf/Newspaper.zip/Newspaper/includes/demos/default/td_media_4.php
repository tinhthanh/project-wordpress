<?php
/**
 * Created by ra on 6/13/2015.
 */
td_demo_media::add_image_to_media_gallery('td_pic_13',                  "http://demo_content.tagdiv.com/Newspaper_6/default_8/13.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_14',                  "http://demo_content.tagdiv.com/Newspaper_6/default_8/14.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_15',                  "http://demo_content.tagdiv.com/Newspaper_6/default_8/15.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_16',                  "http://demo_content.tagdiv.com/Newspaper_6/default_8/16.jpg");