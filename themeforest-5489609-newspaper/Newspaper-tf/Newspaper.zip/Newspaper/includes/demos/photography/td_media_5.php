<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_pic_p7',                  "http://demo_content.tagdiv.com/Newspaper_6/photography/p7.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p8',                  "http://demo_content.tagdiv.com/Newspaper_6/photography/p8.jpg");

//logo
td_demo_media::add_image_to_media_gallery('td_logo_header',             'http://demo_content.tagdiv.com/Newspaper_6/photography/logo-header.png');
td_demo_media::add_image_to_media_gallery('td_logo_header_retina',      'http://demo_content.tagdiv.com/Newspaper_6/photography/logo-header@2x.png');


