<?php
td_demo_media::add_image_to_media_gallery('td_pic_p2',                  "http://demo_content.tagdiv.com/Newspaper_6/magazine/p2.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newspaper_6/magazine/p3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p4',                  "http://demo_content.tagdiv.com/Newspaper_6/magazine/p4.jpg");
td_demo_media::add_image_to_media_gallery('td_logo_header',             'http://demo_content.tagdiv.com/Newspaper_6/magazine/logo-header.png');
td_demo_media::add_image_to_media_gallery('td_logo_header@2x',          'http://demo_content.tagdiv.com/Newspaper_6/magazine/logo-header@2x.png');