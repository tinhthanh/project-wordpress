<?php
td_demo_media::add_image_to_media_gallery('td_pic_13',                  "http://demo_content.tagdiv.com/Newspaper_6/black/13.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_14',                  "http://demo_content.tagdiv.com/Newspaper_6/black/14.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_15',                  "http://demo_content.tagdiv.com/Newspaper_6/black/15.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p1',                  "http://demo_content.tagdiv.com/Newspaper_6/black/p1.jpg");